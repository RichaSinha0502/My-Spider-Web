﻿using LanguageExt.TypeClasses;
using Richa_Sinha_Forefront.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Richa_Sinha_Forefront.Controllers
{
    public class HomeController : Controller
    {
        private Coordinates wall = new Coordinates();

        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Details(InputData frm)
        {
            String Instruction_AllowableChars = "fFlLrR";
            String Orientation = "";
            if(ModelState.IsValid)
            {
                //Instruction validation
                foreach (char c in frm.Instructions)
                {
                    if (!Instruction_AllowableChars.Contains(c.ToString()))
                    {
                        ModelState.AddModelError("Instructions", "Instructions can have F/f, L/l and R/r only");
                        return View("Index");
                    }                   
                }
                //WallSize validation
                if (!ValidateWallSize(frm))
                {
                    ModelState.AddModelError("WallSize", "Wall Size should be the x and y co-ordinates separated by space for e.g. 7 15 ");
                    return View("Index");
                }

                //CurrentLocation and Orientation validation
                if (!ValidateCurrLocation_Orientation(frm))
                {
                    ModelState.AddModelError("CurrentLocation", "The second line of input is information about the spider’s current location and orientation.This is made up of two integers and a word separated by spaces, corresponding to the x andy coordinates and the spider's orientation. E.g. 4 10 Left ");
                    return View("Index");
                }
                ViewBag.WallSizeOut = frm.WallSize;
                ViewBag.CurrentLocationOut = frm.CurrentLocation;
                ViewBag.InstructionsOut = frm.Instructions;
                
                Coordinates FinalCoordinates = new Coordinates();
                FinalCoordinates = CalculatePosition(frm,ref Orientation);
                if(FinalCoordinates.x >wall.x || FinalCoordinates.y >wall.y)
                {
                    ViewBag.Coordinates = "Oops, the spider escaped the wall, your final co-ordinates are more than the wall size." + FinalCoordinates.x +" " +FinalCoordinates.y+ " " +Orientation;
                    return View("Index");
                }
                    
                ViewBag.Coordinates = FinalCoordinates.x +" " +FinalCoordinates.y+ " " +Orientation;
                return View("Index");
            }
            else
            {
                ViewBag.WallSizeOut = "No Data";
                ViewBag.CurrentLocationOut = "No Data";
                ViewBag.InstructionsOut = "No Data";
                return View("Index");
            }
            
        }

        private bool ValidateCurrLocation_Orientation(InputData frm)
        {
            string[] n = frm.CurrentLocation.Split(' ');
            if(n.Length ==3)
            {
                if (int.TryParse(n[0], out int a) == true && int.TryParse(n[1], out int b) == true && n.Length == 3 & new[] { "left", "right", "up", "down" }.Contains(n[2].ToLower()))
                    return true;
                else
                    return false;
            }
            else
                return false;
        }

        private bool ValidateWallSize(InputData frm)
        {
            string[] n = frm.WallSize.Split(' ');
            if (int.TryParse(n[0], out int a) == true && int.TryParse(n[1], out int b) == true && n.Length == 2)
                return true;
            else
                return false;
        }

        private Coordinates CalculatePosition(InputData frm,ref String Orientation)
        {
            
            String Instructions = "";
            string[] n = frm.WallSize.Split(' ');
            wall.x = Int32.Parse(n[0]);
            wall.y = Int32.Parse(n[1]);

            Coordinates Position = new Coordinates();
            n = frm.CurrentLocation.Split(' ');
            Position.x = Int32.Parse(n[0]);
            Position.y = Int32.Parse(n[1]);
            Orientation = n[2].ToLower();

            Instructions = frm.Instructions.ToUpper();

            foreach(Char c in Instructions)
            {
              
                
                if(c==Char.Parse("F"))
                {
                    if(Orientation=="left")
                        Position.x = Position.x - 1;
                    if (Orientation == "right")
                        Position.x = Position.x + 1;
                    if (Orientation == "up")
                        Position.y = Position.y+ 1;
                    if (Orientation == "down")
                        Position.y = Position.y - 1;
                }
                if (c == Char.Parse("L"))
                {
                    switch (Orientation)
                    {
                        case "left":
                            Orientation = "down";
                            break;
                        case "right":
                            Orientation = "up";
                            break;
                        case "up":
                            Orientation = "left";
                            break;
                        case "down":
                            Orientation = "right";
                            break;
                        default:
                            break;

                    }
                }
                if (c == Char.Parse("R"))
                {
                    switch (Orientation)
                    {
                        case "left":
                            Orientation = "up";
                            break;
                        case "right":
                            Orientation = "down";
                            break;
                        case "up":
                            Orientation = "right";
                            break;
                        case "down":
                            Orientation = "left";
                            break;
                        default:
                            break;
                    }

                }
            }

            return Position;

        }
    }
}