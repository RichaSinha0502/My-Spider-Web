﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Richa_Sinha_Forefront.Models
{
    public class Location
    {
        public int x { get; set; }
        public int y { get; set; }
        public string orientation { get; set; }
    }
    public class Coordinates
    {
        public int? x { get; set; }
        public int? y { get; set; }
    }
}