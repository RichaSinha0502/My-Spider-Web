﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Richa_Sinha_Forefront.Models
{
    public class InputData
    {
        [Required]
        [StringLength(50)]
        public string WallSize { get; set; }
        [Required]
        [StringLength(50)]
        public string CurrentLocation { get; set; }
        [Required]
        [StringLength(50)]
        public string Instructions { get; set; }
        //We could use Regex for validation
    }
}