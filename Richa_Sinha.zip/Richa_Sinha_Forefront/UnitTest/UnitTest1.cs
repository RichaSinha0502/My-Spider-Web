﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Richa_Sinha_Forefront.Controllers;
using Richa_Sinha_Forefront.Models;
using System;
using System.Web.Mvc;

namespace UnitTest
{
    [TestClass]
    public class Controllertest
    {
        [TestMethod]
        public void Test_Instructions()
        {
            //Arrange
            var controller = new HomeController();
            var frm = new InputData();
            frm.WallSize = "7 15";
            frm.CurrentLocation = "4 10 Left";
            frm.Instructions = "FLFLFRFFLF";
            //Act
            var result = controller.Details(frm) as ViewResult;
            //Assert
            Assert.AreEqual("5 7 right", result.ViewData["Coordinates"]);
        }
    }
}
